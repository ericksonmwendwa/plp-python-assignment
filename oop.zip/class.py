# Base class
class Book:
    def __init__(self, title, author, pages):
        self._title = title
        self._author = author
        self._pages = pages

    def get_info(self):
        return f"'{self._title}' by {self._author}, {self._pages} pages."


# Subclass for Ebooks
class Ebook(Book):
    def __init__(self, title, author, pages, file_size):
        super().__init__(title, author, pages)
        self._file_size = file_size  # extra attribute for Ebook

    def get_info(self):
        return f"E-Book: '{self._title}' by {self._author}, {self._pages} pages, File Size: {self._file_size}MB."

    def download(self):
        return f"Downloading '{self._title}'..."


# Subclass for Audiobooks
class Audiobook(Book):
    def __init__(self, title, author, pages, length_minutes):
        super().__init__(title, author, pages)
        self._length_minutes = length_minutes

    def get_info(self):
        return f"Audiobook: '{self._title}' by {self._author}, Length: {self._length_minutes} minutes."

    def play_sample(self):
        return f"Playing a sample of '{self._title}'..."


# Creating objects
physical_book = Book("The Lightning Thief", "Rick Riordan", 377)
ebook = Ebook("The Sea of Monsters", "Rick Riordan", 304, 5)
audiobook = Audiobook("The Titan's Curse", "Rick Riordan", 312, 480)

# Print info
print(physical_book.get_info())
print(ebook.get_info())
print(ebook.download())
print(audiobook.get_info())
print(audiobook.play_sample())
