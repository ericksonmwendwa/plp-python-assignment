# Base class for Vehicle
class Vehicle:
    def __init__(self, name):
        self.name = name

    def move(self):
        pass


# Car
class Car(Vehicle):
    def __init__(self, name, make):
        super().__init__(name)
        self.make = make

    def move(self):
        print(f"{self.name} is driving on the road")


# Plane
class Plane(Vehicle):
    def __init__(self, name, airline):
        super().__init__(name)
        self.airline = airline

    def move(self):
        print(f"{self.name} is flying in the sky")


# Boat
class Boat(Vehicle):
    def __init__(self, name, type_of_boat):
        super().__init__(name)
        self.type_of_boat = type_of_boat

    def move(self):
        print(f"{self.name} is sailing across the water")


# Creating objects for each vehicle
car = Car("Kia Sportage", "Kia")
plane = Plane("Boeing 747", "Kenya Airways")
boat = Boat("DreamBoat", "Oceanco")

# Calling the move() method on each object
car.move()
plane.move()
boat.move()
